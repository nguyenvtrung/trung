n = new Date();
y = n.getFullYear();
m = n.getMonth() + 1;
d = n.getDate();
t = n.getDay() + 1 ;
console.log("%cHi xin chào , hôm nay là ngày " + d + " tháng " + m + " năm " + y ,"font-size: 20px; color: red");
console.log("%cMy name is : " + "%cTrung" , "color : blue;" , "color : red; font-weight: bold;font-size: 18px ");